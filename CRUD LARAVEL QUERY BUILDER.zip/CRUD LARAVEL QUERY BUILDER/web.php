<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\UserController;
use Illuminate\Http\Request;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// CREATE
Route::get('/user/create', [UserController::class,'create'])->name('users.create');
Route::post('/user/store', [UserController::class,'store'])->name('users.store');
// READ
Route::get('/user', [UserController::class,'index'])->name('users.index');
Route::get('/user/{id}', [UserController::class,'show'])->name('users.show');
// UPDATE
Route::get('/user/{id}/edit', [UserController::class,'edit'])->name('users.edit');
Route::post('/user/{id}/update', [UserController::class,'update'])->name('users.update');
// DELETE
Route::get('/user/{id}/delete', [UserController::class,'delete'])->name('users.delete');



